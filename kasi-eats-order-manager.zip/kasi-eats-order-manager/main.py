"""Kasi Eats Order Manager - Soweto. Milestones 1-8 covered."""
import json
import csv
import datetime
from pathlib import Path
from utils import format_rand, get_valid_int, get_valid_float, calculate_change_breakdown, clean_input
from models import MenuItem, Order

STALL_NAME = "Kasi Eats"
OWNER_NAME = "Mama Thandi"
LOCATION = "Soweto"
VAT_RATE = 0.15
IS_OPEN = True
NUM_TABLES = 8
DATA_DIR = Path(__file__).resolve().parent / "data"


def show_welcome():
    """M1: Welcome banner with f-strings and type()."""
    print("=" * 40)
    print(f" {STALL_NAME} ORDER MANAGER - {LOCATION}")
    print("=" * 40)
    print(f"Stall: {STALL_NAME} | Owner: {OWNER_NAME}")
    print(f"VAT Rate: {VAT_RATE * 100}%")
    print(f"Types: {STALL_NAME} is {type(STALL_NAME)}, VAT is {type(VAT_RATE)}, IS_OPEN is {type(IS_OPEN)}, Tables {type(NUM_TABLES)}")
    cashier = clean_input(input("Cashier name: ")).title()
    if not cashier:
        cashier = "Lerato"
    print(f"Sawubona, {cashier}! Let's sell some kotas.\n")
    return cashier


def load_menu():
    """M6: Load menu from JSON with FileNotFoundError handling."""
    try:
        with open(DATA_DIR / "menu.json", "r", encoding="utf-8") as f:
            data = json.load(f)
        return {k: MenuItem(k, v) for k, v in data.items()}
    except FileNotFoundError:
        print("! data/menu.json not found - using default menu")
        default = {"kota": 35.00, "vetkoek": 12.50, "chips": 25.00, "cooldrink": 15.00, "pap & wors": 55.00, "bunny chow": 70.00}
        return {k: MenuItem(k, v) for k, v in default.items()}
    except (json.JSONDecodeError, ValueError, TypeError):
        print("! menu.json corrupted")
        return {}


def show_menu(menu):
    """M5: Display menu."""
    print("\n----- MENU -----")
    for i, (name, item) in enumerate(menu.items(), 1):
        print(f"{i}. {item.name.title():<15} {format_rand(item.price)}")
    print("----------------")


def take_order(menu, unique_sold_today):
    """M5: Take order and return Order object."""
    order = Order()
    while True:
        raw = clean_input(input("Item (or 'done'): "))
        if raw == "done":
            break
        if raw not in menu:
            print(f"! Unknown item '{raw}'. Try: {', '.join(menu.keys())}")
            continue
        qty = get_valid_int("Quantity: ")
        if qty is None:
            continue
        if qty <= 0:
            print("! Quantity must be > 0")
            continue
        item = menu[raw]
        line_total = item.price * qty
        order.add_item(item.name, qty, line_total)
        unique_sold_today.add(raw)
    return order


def calculate_total(order, vat_rate=VAT_RATE):
    """M5: Calculate subtotal, discount, VAT and total."""
    subtotal = order.subtotal()
    discount = apply_discount(subtotal)
    taxable = subtotal - discount
    vat = taxable * vat_rate
    total = taxable + vat
    return subtotal, discount, vat, total


def apply_discount(subtotal):
    """M3: 10% discount for subtotals of R200 or more."""
    if subtotal >= 200:
        return subtotal * 0.10
    return 0.0


def print_receipt(order):
    """M4: Print aligned receipt."""
    subtotal, discount, vat, total = calculate_total(order)
    print("\n------------- RECEIPT -------------")
    for name, qty, line in order.items:
        print(f"{name.title():<15}{qty:>3} {format_rand(line):>10}")
    print("-----------------------------------")
    print(f"{'Subtotal':<15} {format_rand(subtotal):>15}")
    if discount > 0:
        print(f"{'Discount 10%':<15} -{format_rand(discount):>14}")
    print(f"{'VAT (15%)':<15} {format_rand(vat):>15}")
    print(f"{'TOTAL':<15} {format_rand(total):>15}")
    return total


def save_sale(order, total):
    """M6: Append sale to CSV with timestamp."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    sales_file = DATA_DIR / "sales.csv"
    try:
        with open(sales_file, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            if f.tell() == 0:
                writer.writerow(["datetime", "items", "total"])
            items_str = "; ".join(f"{n} x{q}" for n, q, _ in order.items)
            writer.writerow([datetime.datetime.now().isoformat(), items_str, f"{total:.2f}"])
        print("Order saved to data/sales.csv")
    except OSError as e:
        print(f"! Could not save sale: {e}")


def daily_summary():
    """M6: Summarise today's orders from sales.csv."""
    try:
        with open(DATA_DIR / "sales.csv", "r", encoding="utf-8", newline="") as f:
            rows = [r for r in csv.DictReader(f) if datetime.date.fromisoformat(r["datetime"][:10]) == datetime.date.today()]
        if not rows:
            print("No sales today.")
            return
        total_takings = sum(float(r["total"]) for r in rows)
        from collections import Counter
        counts = Counter()
        for r in rows:
            for part in r["items"].split(";"):
                if " x" in part:
                    name, qty = part.rsplit(" x", 1)
                    counts[name.strip().lower()] += int(qty)
        best = counts.most_common(1)[0][0].title() if counts else "None"
        print(f"Orders today: {len(rows)} | Takings: {format_rand(total_takings)} | Best seller: {best}")
    except FileNotFoundError:
        print("No sales yet - data/sales.csv not found")
    except (OSError, ValueError, KeyError) as e:
        print(f"Error reading summary: {e}")


def main():
    """Main menu loop covering milestones 1-8."""
    cashier = show_welcome()
    menu = load_menu()
    unique_sold_today = set()
    while True:
        print("\n1. New order  2. View menu  3. Daily summary  4. Exit")
        choice = clean_input(input("Choose an option: "))
        if choice == "1":
            if not IS_OPEN:
                print("Stall is closed")
                continue
            order = take_order(menu, unique_sold_today)
            if not order.items:
                print("No items - order cancelled")
                continue
            total = print_receipt(order)
            cash = get_valid_float("Cash paid: ")
            if cash is None:
                continue
            if cash < total:
                print(f"! Cash less than total. Need {format_rand(total)}")
                continue
            change = round(cash - total, 2)
            r10, remainder = calculate_change_breakdown(change)
            print(f"Change {format_rand(change)} ({r10} x R10 + {format_rand(remainder)})")
            save_sale(order, total)
        elif choice == "2":
            show_menu(menu)
        elif choice == "3":
            daily_summary()
            print(f"Unique items sold today: {unique_sold_today}")
        elif choice == "4":
            print("Sala kahle! Sales saved.")
            break
        else:
            print("! Invalid option - choose 1-4")
            continue


if __name__ == "__main__":
    main()
