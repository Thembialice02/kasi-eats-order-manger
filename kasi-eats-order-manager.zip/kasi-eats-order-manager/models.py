"""MenuItem and Order classes - Milestone 8."""


class MenuItem:
    """Represents a menu item."""
    def __init__(self, name, price):
        self.name = name.strip().lower()
        self.price = float(price)

    def __str__(self):
        return f"{self.name.title()} - R {self.price:.2f}"


class Order:
    """Holds a list of (item, quantity, line total) tuples."""
    def __init__(self):
        self.items = []

    def add_item(self, name, qty, line_total):
        self.items.append((name, qty, line_total))

    def subtotal(self):
        return sum(line for _, _, line in self.items)

    def total(self):
        return self.subtotal()
