# Kasi Eats Order Manager

A menu-driven CLI Python program for Mama Thandi's township food stall in Soweto. Takes food orders, calculates subtotal, 10% discount, 15% VAT, change with R10 units, and saves sales to CSV offline.

## How to run

Requires Python 3.10+.

```bash
git clone https://github.com/Thembialice02/kasi-eats-order-manager
cd kasi-eats-order-manager
python main.py
```

If you downloaded the ZIP instead, extract it, open a terminal in the `kasi-eats-order-manager` folder, and run `python main.py`. No extra Python packages are required.

## Features

- Welcome banner with f-strings and data types (M1)
- Subtotal, VAT, discount, change with `//` and `%` (M2, M3)
- Main menu `while` loop with validation (M3)
- Dictionary menu, list of tuples order, set of unique items, string methods (M4)
- Six or more functions with docstrings (M5)
- Loads `data/menu.json`, saves `data/sales.csv` using `with open` (M6)
- `try/except` for invalid inputs and missing files (M7)
- `MenuItem` and `Order` classes (M8)

## Example run

```text
KASI EATS ORDER MANAGER - Soweto
Cashier name: Lerato
Sawubona, Lerato! Let's sell some kotas.

1. New order  2. View menu  3. Daily summary  4. Exit
Choose an option: 1
Item (or 'done'): kota
Quantity: 2
Item (or 'done'): vetkoek
Quantity: two
! Please enter a whole number.
Quantity: 2
Item (or 'done'): cooldrink
Quantity: 1
Item (or 'done'): done
------------- RECEIPT -------------
Kota              2    R 70.00
Vetkoek           2    R 25.00
Cooldrink         1    R 15.00
-----------------------------------
Subtotal              R 110.00
VAT (15%)              R 16.50
TOTAL                 R 126.50
Cash paid: 150
Change R 23.50 (2 x R10 + R 3.50)
Order saved to data/sales.csv
```

The program creates `data/sales.csv` after the first completed paid order. This file is ignored by Git.

## Git milestones

To earn marks for milestone history, make genuine commits **as you build each milestone**. Running eight commit commands on unchanged files does not create eight meaningful commits. The commands below are suggested commit messages for actual stages of development:

```bash
git init
git add .
git commit -m "M1: add welcome banner and core variables"
# Make and stage your M2 changes before committing:
git add .
git commit -m "M2: calculate subtotal, VAT and change"
# Repeat after implementing each subsequent milestone:
git add .
git commit -m "M3: add main menu loop and discount rule"
git add .
git commit -m "M4: store menu and orders in collections; print receipt"
git add .
git commit -m "M5: refactor into functions with docstrings"
git add .
git commit -m "M6: load menu from JSON and save sales to CSV"
git add .
git commit -m "M7: add input validation and error handling"
git add .
git commit -m "M8: introduce MenuItem and Order classes; complete README"
```

To push your repository after configuring a remote and branch:

```bash
git remote add origin https://github.com/Thembialice02/kasi-eats-order-manager.git
git branch -M main
git push -u origin main
git log --oneline
```

**Important:** This ZIP contains the completed source files, not a fabricated Git commit history. Create commits as you actually work on the project.

## Project details

Code is my own. (Confirm this statement is accurate before submitting.)

Name: Thembi Masete | Cohort: Simphiwe Coka | Date: Nov 2026 | Location: Soweto

GitHub: https://github.com/Thembialice02/kasi-eats-order-manager
