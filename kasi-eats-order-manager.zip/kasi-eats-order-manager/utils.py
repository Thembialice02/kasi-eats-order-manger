"""Helper functions - formatting, validation."""


def format_rand(amount):
    """Format amount as R 00.00."""
    return f"R {amount:.2f}"


def clean_input(text):
    """M4: Strip whitespace and lowercase input."""
    return text.strip().lower()


def get_valid_int(prompt):
    """M7: Validate whole-number input with try/except."""
    while True:
        try:
            raw = input(prompt).strip()
            if raw == "":
                print("! Please enter a number")
                continue
            return int(raw)
        except ValueError:
            print("! Please enter a whole number.")
            continue


def get_valid_float(prompt):
    """M7: Validate non-negative cash input."""
    while True:
        try:
            value = float(input(prompt).strip())
            if not 0 <= value < float("inf"):
                print("! Please enter a non-negative, finite amount")
                continue
            return value
        except ValueError:
            print("! Please enter a valid amount")
            continue


def calculate_change_breakdown(change):
    """M2: Use integer division and modulo for R10 units."""
    cents = round(change * 100)
    r10_coins = cents // 1000
    remainder = (cents % 1000) / 100
    return r10_coins, remainder
